//
//  ImmersiveView.swift
//  calitest_app
//
//  Created by 陶文晖 on 2025/3/9.
//

import SwiftUI
import RealityKit
import RealityKitContent
import ARKit
import Accelerate
import Foundation
import simd


// 定义符合 Codable 协议的结构体
struct Response: Codable {
    let yaw: Float
    let pitch: Float
    let roll: Float
}

struct ImmersiveView: View {
    @State private var points: [String: [Int]] = [:]
    @ObservedObject var gestureModel: CaliGestureModel
    @State private var handEntities: [String: ModelEntity] = [:]
    @State private var THandEntities: [String: ModelEntity] = [:]
    @State var lineEntities: [String: ModelEntity] = [:]
    @State private var TlineEntities: [String: ModelEntity] = [:]
    @State var teacherMaterials: [PhysicallyBasedMaterial] = []
    @State var tPenMaterials: [PhysicallyBasedMaterial] = []
    @State var cylinderEntities: [Int: ModelEntity] = [:]
    @State var extractedPoints: [(Int, Int)] = []
    @State var shadow: [[String: ModelEntity]] = []
    @State private var canvasOffset = CGSize.zero
    @State private var scale: CGFloat = 1.0
    @State private var canvaZ: Float = 0
    @State var count = 0
    @State var paperLevel: CGFloat = CGFloat.infinity
    // 定义需要连接的关节对（起点，终点）
       let connections: [(String, String)] = [
           ("thumbKnuckle", "thumbIntermediateBase"),
           ("thumbIntermediateBase", "thumbIntermediateTip"),
           ("thumbIntermediateTip", "thumbTip"),
           
           ("indexFingerMetacarpal", "indexFingerKnuckle"),
           ("indexFingerKnuckle", "indexFingerIntermediateBase"),
           ("indexFingerIntermediateBase", "indexFingerIntermediateTip"),
           ("indexFingerIntermediateTip", "indexFingerTip"),
           
           ("middleFingerMetacarpal", "middleFingerKnuckle"),
           ("middleFingerKnuckle", "middleFingerIntermediateBase"),
           ("middleFingerIntermediateBase", "middleFingerIntermediateTip"),
           ("middleFingerIntermediateTip", "middleFingerTip"),
           
           ("ringFingerMetacarpal", "ringFingerKnuckle"),
           ("ringFingerKnuckle", "ringFingerIntermediateBase"),
           ("ringFingerIntermediateBase", "ringFingerIntermediateTip"),
           ("ringFingerIntermediateTip", "ringFingerTip"),
           
           ("littleFingerMetacarpal", "littleFingerKnuckle"),
           ("littleFingerKnuckle", "littleFingerIntermediateBase"),
           ("littleFingerIntermediateBase", "littleFingerIntermediateTip"),
           ("littleFingerIntermediateTip", "littleFingerTip"),
           
           ("wrist", "thumbKnuckle"),
           ("wrist", "indexFingerMetacarpal"),
           ("wrist", "middleFingerMetacarpal"),
           ("wrist", "ringFingerMetacarpal"),
           ("wrist", "littleFingerMetacarpal"),
           ("wrist", "forearmArm")
       ]

    var body: some View {
        
        ZStack {
            Canvas { context, size in
                if let positions = loadJsonWithSerialization(filename: "yong") {
                    for position in positions {
                        let x = CGFloat(position[0]) / 800 * size.width  // 适配 Canvas 宽度
                        let z = CGFloat(position[1]) / 800 * size.height // `y` 变 `z`

                        let pointRect = CGRect(x: x, y: z, width: 5, height: 5) // 点的大小
                        context.fill(Path(ellipseIn: pointRect), with: .color(.blue))
                    }
                }
            }
            .frame(width: 400, height: 400) // 画布大小
            .rotation3DEffect(.degrees(90), axis: (1, 0, 0)) // 旋转到 X-Z 平面
            .offset(x: canvasOffset.width, y: canvasOffset.height)
            .offset(z: CGFloat(canvaZ) * 1000)
            .scaleEffect(scale) // 缩放
            .gesture(
                                
  
                                    MagnificationGesture()
                                        .onChanged { value in
                                            scale = value // 缩放时更新比例
                                        }

                            )
//                Canvas { context, size in
//                    if let parsedData = loadStrokeJSON() {
//                        for (key, value) in parsedData {
//                            if let match = key.range(of: #"(\d+), (\d+)"#, options: .regularExpression) {
//                                let parts = key[match.lowerBound..<match.upperBound]
//                                    .split(separator: ",")
//                                    .map { Int($0.trimmingCharacters(in: .whitespaces)) ?? 0 }
//
//                                if parts.count == 2 {
//                                    let x = CGFloat(parts[0]) / 800 * size.width  // 适配 Canvas 宽度
//                                    let z = CGFloat(parts[1]) / 800 * size.height // `y` 变 `z`
//
//                                    let pointRect = CGRect(x: x, y: z, width: 5, height: 5) // 点的大小
//                                    context.fill(Path(ellipseIn: pointRect), with: .color(.blue))
//                                }
//                            }
//                        }
//                    }
//                }
//                .frame(width: 400, height: 400) // 画布大小
//                .rotation3DEffect(.degrees(90), axis: (1, 0, 0)) // 旋转到 X-Z 平面
//                .offset(x: canvasOffset.width, y: canvasOffset.height)
//                .offset(z: CGFloat(canvaZ) * 1000)
//                .scaleEffect(scale) // 缩放
//                .gesture(
//                    gestureModel.mode == .changewriting ?
//                            SimultaneousGesture(
//                                DragGesture()
//                                    .onChanged { gesture in
//                                        canvasOffset = gesture.translation // 拖动时更新 offset
//                                    },
//                                MagnificationGesture()
//                                    .onChanged { value in
//                                        scale = value // 缩放时更新比例
//                                    }
//                            ) : nil
//                )
            
            // RealityView 用于展示圆柱体
            RealityView { content in
                for (key, entity) in handEntities {
                    content.add(entity)
                }
                for (key, entity) in THandEntities {
                    content.add(entity)
                }
                for (key, entity) in lineEntities {
                    content.add(entity)
                }
                for (key, entity) in TlineEntities {
                    content.add(entity)
                }
                for entity in shadow {
                    if let pen = entity["pen"],
                        let arrow = entity["arrow"]{
                        content.add(pen)
                        content.add(arrow)
                    }
                }
                
                
                if gestureModel.mode == .practice {
                    let sphereMesh = MeshResource.generateSphere(radius: 0.002)
                    
                    var previousThumbPosition: SIMD3<Float>? // 记录上一个拇指位置
                    for (index, handData) in gestureModel.handTrackingData.enumerated().dropFirst(100) {
                        var extendedPosition: SIMD3<Float> = .zero
//                        获得笔尖的位置
                        if let thumbPosition = handData["thumbTip"],
                        let indexPosition = handData["indexFingerTip"],
                        let middlePosition = handData["middleFingerTip"]
                        {
                            let direction = normalize(middlePosition.position - indexPosition.position)
                            let penPosition = (thumbPosition.position + indexPosition.position) / 2
                            extendedPosition = penPosition + direction * 0.1
                            if CGFloat(extendedPosition.y) < paperLevel {
                                paperLevel = CGFloat(extendedPosition.y)
                            }
                            gestureModel.pathData1.append([CGFloat(extendedPosition.x),CGFloat(extendedPosition.z)])
                        }
                        if false
                            
//                            index % 50 == 0
//                            let thumb = handData["thumbTip"]
                        {
                            if CGFloat(extendedPosition.y) > paperLevel + 0.05 {
                                continue
                            }
                            var material = PhysicallyBasedMaterial()
                            setBaseColor(Material: &material, color: .blue)
                            material.blending = .transparent(opacity: .init(floatLiteral: 0.2))
                            // 创建球体
                            let sphereEntity = ModelEntity(mesh: sphereMesh, materials: [material])
                            sphereEntity.position = extendedPosition + SIMD3<Float>(Float(gestureModel.Xoffset), Float(gestureModel.Yoffset), Float(gestureModel.Zoffset))
                            content.add(sphereEntity)
                            
                            // 如果有上一个拇指位置，创建圆柱体连接它们
                            if let previous = previousThumbPosition {
                                let cylinderEntity = createCylinder(from: previous, to: extendedPosition + SIMD3<Float>(Float(gestureModel.Xoffset), Float(gestureModel.Yoffset), Float(gestureModel.Zoffset)), radius: 0.001, material: material)
                                content.add(cylinderEntity)
                                cylinderEntities[index] = cylinderEntity
                            }
                            
                            // 更新前一个拇指位置
                            previousThumbPosition = extendedPosition + SIMD3<Float>(Float(gestureModel.Xoffset), Float(gestureModel.Yoffset), Float(gestureModel.Zoffset))
                        }
                    }
                }

                // 生成连接两个点的圆柱体
                func createCylinder(from start: SIMD3<Float>, to end: SIMD3<Float>, radius: Float, material: PhysicallyBasedMaterial) -> ModelEntity {
                    let direction = normalize(end - start)
                    let distance = length(end - start)
                    let cylinderMesh = MeshResource.generateCylinder(height: distance, radius: radius)
                    
                    let cylinderEntity = ModelEntity(mesh: cylinderMesh, materials: [material])
                    
                    // 计算圆柱体的位置和旋转
                    cylinderEntity.position = (start + end) / 2
                    cylinderEntity.orientation = simd_quatf(from: SIMD3<Float>(0, 1, 0), to: direction)
                    
                    return cylinderEntity
                }

            }
            update:{
                updateContent in
                if count < 201 {
                        DispatchQueue.main.async {
                            count += 1
                        }
                        return
                    }
                let hand = gestureModel.computeTransformOfUserPerformedHeartGesture()
                
                if let jointPositions = hand {
                    for (key, entity) in handEntities {
                        if let position = jointPositions[key] {
                            entity.position = position
                                }
                    }
                    var extendedPosition:SIMD3<Float> = .zero
                    
                    var currentData: [String: CaliGestureModel.EntityPositionData] = [:]
                    for (key, entity) in handEntities {
                        currentData[key] =
                        CaliGestureModel.EntityPositionData(from: entity.position)
                    }
                    updatePenArrow(HandData: currentData, handEntities: handEntities)
                    if !currentData.isEmpty {
                        let angles = computeFingerAngles(handData:currentData)
                        for (key, angle) in angles {
                            guard let entity = handEntities[key] else { continue }

                                let absAngle = abs(angle) // 取绝对值
                                let color = angleToRainbowColor(angle: absAngle) // 计算彩虹色
                                
                                let material = SimpleMaterial(color: color, isMetallic: false)
                                entity.model?.materials = [material] // 应用颜色
                            }
                    }
                    updateLines()
//                    if let posi = currentData["thumbTip"]?.position
                    if count == 201
                    {
                        let newOffset = CGSize(
                            width: (
//                                CGFloat(posi.x) +
                                    gestureModel.Xoffset) * 1000,   // 适配 SwiftUI 画布
                            height: (
//                                CGFloat(-posi.y) -
                                gestureModel.Yoffset - 0.10) * 1000  // 取反，适配屏幕方向
                        )

                        DispatchQueue.main.async {
                            canvasOffset = newOffset
                            canvaZ = Float(gestureModel.Zoffset)
                        }
                    }
                    if (gestureModel.mode == .record && gestureModel.isImmersiveActive){
                        
                        if !currentData.isEmpty {
                            DispatchQueue.main.async {
                                gestureModel.handTrackingData.append(currentData)
                            }
                        }
                    }else if (gestureModel.mode == .practice && gestureModel.isImmersiveActive){
                        if let thumbPosition = jointPositions["thumbTip"],
                        let indexPosition = jointPositions["indexFingerTip"],
                        let middlePosition = jointPositions["middleFingerTip"]
                        {
                            let direction = normalize(middlePosition - indexPosition)
                            let penPosition = (thumbPosition + indexPosition) / 2
                            extendedPosition = penPosition + direction * 0.1
                            gestureModel.recordPoint(x: CGFloat(extendedPosition.x), y: CGFloat(extendedPosition.z))
                        }
                        
                        if gestureModel.GestureIndex+50 >= gestureModel.handTrackingData.count {
                            print(gestureModel.GestureIndex)
                            print(gestureModel.matchStartIndex)
                            print("...")
                            return
                        }
                        var TCurrentData = gestureModel.handTrackingData[gestureModel.GestureIndex+50]

                        updateTHand(TCurrentData: TCurrentData)
                        
                        
//                        var update = true
//                        if let targetPosition = TCurrentData["thumbTip"]?.position,
//                           let entity = handEntities["thumbTip"]{
//                            let distance = simd_distance(entity.position, targetPosition + SIMD3<Float>(Float(gestureModel.Xoffset), Float(gestureModel.Yoffset), Float(gestureModel.Zoffset)))
//                            if (distance > 0.1){
//                                update = false
//                            }
//                        }
//                        if let targetPosition = TCurrentData["indexFingerTip"]?.position,
//                           let entity = handEntities["indexFingerTip"]{
//                            let distance = simd_distance(entity.position, targetPosition + SIMD3<Float>(Float(gestureModel.Xoffset), Float(gestureModel.Yoffset), Float(gestureModel.Zoffset)))
//                            if (distance > 0.1){
//                                update = false
//                            }
//                        }
//                        if let targetPosition = TCurrentData["middleFingerTip"]?.position,
//                           let entity = handEntities["middleFingerTip"]{
//                            let distance = simd_distance(entity.position, targetPosition + SIMD3<Float>(Float(gestureModel.Xoffset), Float(gestureModel.Yoffset), Float(gestureModel.Zoffset)))
//                            if (distance > 0.1){
//                                update = false
//                            }
//                        }
//                        for (key, entity) in handEntities {
//                            if let targetPosition = TCurrentData[key]?.position {
//                                let distance = simd_distance(entity.position, targetPosition + SIMD3<Float>(Float(gestureModel.Xoffset), Float(gestureModel.Yoffset), Float(gestureModel.Zoffset)))
//                                if (key != "pen" && distance > 0.1){
//                                    update = false
//                                    break
//                                }
//                            }
//                        }
                        
                        if CGFloat(extendedPosition.y) > paperLevel + 0.05 {
                            DispatchQueue.main.async {
                                gestureModel.matchStartIndex += 1
                            }
                        }
                        
                        DispatchQueue.main.async {
                            gestureModel.GestureIndex = gestureModel.matchStartIndex
                        }
                        

                    }
                }
            }
            .task {
                await gestureModel.start()
            }
            .task {
                await gestureModel.publishHandTrackingUpdates()
            }
            .task {
                await gestureModel.monitorSessionEvents()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            
        }.onAppear {
            if let parsedData = loadStrokeJSON() {
               self.points = parsedData
           }
            createSphereEntity()
        }
    
    }
    
    func interpolatedColor(progress: CGFloat) -> UIColor {
        let red = progress
        let green: CGFloat = 0
        let blue = 1 - progress

        return UIColor(red: red, green: green, blue: blue, alpha: 1.0)
    }
    
    func loadJsonWithSerialization(filename: String) -> [[Int]]? {
        guard let url = Bundle.main.url(forResource: filename, withExtension: "json") else {
            print("JSON 文件未找到")
            return nil
        }
        
        do {
            let data = try Data(contentsOf: url)
            let json = try JSONSerialization.jsonObject(with: data, options: [])
            return json as? [[Int]]
        } catch {
            print("解析 JSON 失败: \(error)")
            return nil
        }
    }
    
    func loadStrokeJSON() -> [String: [Int]]? {
            guard let url = Bundle.main.url(forResource: "output_stroke", withExtension: "json") else {
                print("Error: data.json not found in bundle.")
                return nil
            }
            
            do {
                let data = try Data(contentsOf: url)
                
                // 使用 JSONDecoder 解析数据
                let decoder = JSONDecoder()
                
                // 显式地指定解码类型为 [String: [Int]]
                let parsedData = try decoder.decode([String: [Int]].self, from: data)
                
//                // 打印 JSON 内容到控制台
//                print("Loaded JSON data:")
//                for (key, value) in parsedData {
//                    print("Key: \(key), Value: \(value)")
//                }
                return parsedData
            } catch {
                print("Error loading or decoding JSON: \(error)")
                return nil
            }
        }
    
    // 生成连接两个点的圆柱体
    func createCylinder(from start: SIMD3<Float>, to end: SIMD3<Float>, radius: Float, material: PhysicallyBasedMaterial) -> ModelEntity {
        let direction = normalize(end - start)
        let distance = length(end - start)
        let cylinderMesh = MeshResource.generateCylinder(height: distance, radius: radius)
        
        let cylinderEntity = ModelEntity(mesh: cylinderMesh, materials: [material])
        
        // 计算圆柱体的位置和旋转
        cylinderEntity.position = (start + end) / 2
        cylinderEntity.orientation = simd_quatf(from: SIMD3<Float>(0, 1, 0), to: direction)
        
        return cylinderEntity
    }
    func updatePenArrow (HandData: [String: CaliGestureModel.EntityPositionData], handEntities: [String: Entity]){
        if let thumbPosition = HandData["thumbTip"],
           let indexPosition = HandData["indexFingerTip"],
           let middlePosition = HandData["middleFingerTip"],
           let penEntity = handEntities["pen"],
           let arrowEntity = handEntities["arrow"] {
            
            let direction = normalize(middlePosition.position - indexPosition.position)

            
            let penPosition = (thumbPosition.position + indexPosition.position) / 2
            
            var offset = direction * -0.03
            let newPosition = penPosition + offset

            
            penEntity.position = newPosition

            let initialDirection = SIMD3<Float>(0, 1, 0)
            var rotationQuat = simd_quatf(from: initialDirection, to: direction)
            penEntity.orientation = rotationQuat
            
            let fullDirection = normalize(indexPosition.position - thumbPosition.position)

            let xzProjection = normalize(SIMD3<Float>(fullDirection.x, 0, fullDirection.z))

            let perpendicularDirection = -SIMD3<Float>(-xzProjection.z, 0, xzProjection.x)
            offset = direction * -0.07
            let xzoffset = perpendicularDirection * 0.005
            arrowEntity.position = penPosition + offset + xzoffset
            rotationQuat = simd_quatf(from: initialDirection, to: perpendicularDirection)
            arrowEntity.orientation = rotationQuat
            
        }
        
    }
    func normalizeToRange(value: CGFloat, minValue: CGFloat, maxValue: CGFloat, minRange: CGFloat, maxRange: CGFloat) -> CGFloat {
        if value <= minValue {
            return 0.0
        } else if value >= maxValue {
            return 1.0
        } else {
            let normalizedValue = (value - minValue) / (maxValue - minValue)
            return normalizedValue * (maxRange - minRange) + minRange
        }
    }
    
    func updateTPenArrow (HandData: [String: CaliGestureModel.EntityPositionData], handEntities: [String: Entity]){
        
        
        var extendedPosition: SIMD3<Float> = .zero
            
        if let thumbPosition = HandData["thumbTip"],
           let indexPosition = HandData["indexFingerTip"],
           let middlePosition = HandData["middleFingerTip"],
           let penEntity = handEntities["pen"],
           let arrowEntity = handEntities["arrow"],
           let currentThumb = self.handEntities["thumbTip"]?.position{
            
            let thumbOffset = currentThumb - thumbPosition.position
            
            let direction = normalize(middlePosition.position - indexPosition.position) // 方向向量

            
            let penPosition = (thumbPosition.position + indexPosition.position) / 2 + thumbOffset
           
            var offset = direction * -0.03
            let newPosition = penPosition + offset
            extendedPosition = penPosition - thumbOffset + direction * 0.1
           
            penEntity.position = newPosition

            let initialDirection = SIMD3<Float>(0, 1, 0)
            var rotationQuat = simd_quatf(from: initialDirection, to: direction)
            penEntity.orientation = rotationQuat
            
            let fullDirection = normalize(indexPosition.position - thumbPosition.position)

            
            let xzProjection = normalize(SIMD3<Float>(fullDirection.x, 0, fullDirection.z))

          
            let perpendicularDirection = -SIMD3<Float>(-xzProjection.z, 0, xzProjection.x)
            let xzoffset = perpendicularDirection * 0.005
            offset = direction * -0.07
            arrowEntity.position = penPosition + offset + xzoffset
            rotationQuat = simd_quatf(from: initialDirection, to: perpendicularDirection)
            arrowEntity.orientation = rotationQuat
            
//            更新老师的压力
            if let modelEntity = penEntity as? ModelEntity {
                if var material = (modelEntity.model?.materials.first as? PhysicallyBasedMaterial) {
                    let inputValue = CGFloat(extendedPosition.y) - paperLevel
                    let normalizedProgress = normalizeToRange(value: inputValue, minValue: 0, maxValue: 0.05, minRange: 0, maxRange: 1)
                    setBaseColor(Material: &material, color: interpolatedColor(progress: normalizedProgress))
                    modelEntity.model?.materials = [material]
//                    print(normali/*z*/edProgress)
                }
            }
            
        }
    }
    func mapValue(_ x: Float) -> Int {
        if x <= 0.03 {
            return 0
        } else if x > 0.10 {
            return 9
        } else {
            return Int((x - 0.03) / 0.07) * 8 + 1
        }
    }
    
    func updateTmaterial(){
        if let indexTip = handEntities["indexFingerTip"],
           let TindexTip = THandEntities["indexFingerTip"],
           let middleFingerTip = handEntities["middleFingerTip"],
           let TmiddleFingerTip = THandEntities["middleFingerTip"],
           let thumbTip = handEntities["thumbTip"],
           let TthumbTip = THandEntities["thumbTip"],
           let wrist = handEntities["wrist"],
           let Twrist = THandEntities["wrist"]
        {
//            算笔倾斜角度偏差
            let Tvector = TmiddleFingerTip.position(relativeTo: nil) - TindexTip.position(relativeTo: nil)
            let vector = middleFingerTip.position(relativeTo: nil) - indexTip.position(relativeTo: nil)
            let dotProduct = dot(Tvector, vector)
            let magnitudeProduct = length(Tvector) * length(vector)

            let angle = acos(dotProduct / magnitudeProduct) // 弧度
            let angleDegrees = angle * 180 / .pi
            let angleNormalized: Float = Float(angleDegrees) / 1000.0
//            算笔旋转角度偏差
            let TrollVector = TthumbTip.position(relativeTo: nil) - TindexTip.position(relativeTo: nil)
            let rollVector = thumbTip.position(relativeTo: nil) - indexTip.position(relativeTo: nil)
            let rollAngle = acos(dotProduct / magnitudeProduct) // 弧度
            let rollAngleDegrees = angle * 180 / .pi
            let rollAngleNormalized: Float = Float(angleDegrees) / 1000.0
//            算手腕高度
            let yDifference = abs(wrist.position.y - Twrist.position.y)
            let distance = angleNormalized + yDifference + rollAngleNormalized

            let material = teacherMaterials[mapValue(distance)]

            for (key, entity) in THandEntities {
                if key != "pen" && key != "arrow"{
                    entity.model?.materials = [material]
                }
            }
            for (startKey, endKey) in connections {
                if let startEntity = THandEntities[startKey],
                   let endEntity = THandEntities[endKey],
                   let lineEntity = TlineEntities["\(startKey)-\(endKey)"] {
                    lineEntity.model?.materials = [material]
                }
            }
            
        }
        
        
    }
    
    func updateTHand(TCurrentData: [String: CaliGestureModel.EntityPositionData]){
        if let currentThumb = handEntities["thumbTip"]?.position,
           let templateThumb = TCurrentData["thumbTip"]?.position {
            
            // 偏移量 = 当前手的大拇指 - 模板手的大拇指
            let offset = currentThumb - templateThumb

            for (key, entity) in THandEntities {
                if let templateJoint = TCurrentData[key] {
                    // 套用偏移量 + 你自定义的 Y 和 Z 偏移
                    entity.position = templateJoint.position + offset
                }
            }
        }
        

        if gestureModel.GestureIndex % 50 == 0 {
            if let entity = cylinderEntities[gestureModel.GestureIndex+50],
               var material = entity.model?.materials.first as? PhysicallyBasedMaterial {
                
                material.emissiveIntensity = 4.0
                material.emissiveColor = .init(color: .blue)

                entity.model?.materials = [material]
            }
            if let entity = cylinderEntities[gestureModel.GestureIndex],
               var material = entity.model?.materials.first as? PhysicallyBasedMaterial {
                
                material.emissiveIntensity = 0

                entity.model?.materials = [material]
            }
            
        }
        updateTPenArrow(HandData: TCurrentData, handEntities: THandEntities)
        let startIndex = min(gestureModel.GestureIndex + 50, gestureModel.handTrackingData.count)
        var availableData = Array(gestureModel.handTrackingData.suffix(from: startIndex).prefix(150))

        if availableData.count < 150 {
            availableData = Array(gestureModel.handTrackingData.suffix(150))
        }

        for (index, item) in availableData.enumerated() {
            if index % 30 == 0 {
                var extendedPosition: SIMD3<Float> = .zero
                let originalIndex = startIndex + index
                if originalIndex < gestureModel.handTrackingData.count {
                    let originalData = gestureModel.handTrackingData[originalIndex]
                    updateTPenArrow(HandData: originalData, handEntities: shadow[index/30])
                    if let thumbPosition = originalData["thumbTip"]?.position,
                       let indexPosition = originalData["indexFingerTip"]?.position,
                       let middlePosition = originalData["middleFingerTip"]?.position{
                        //            更新残影的压力
                        if  let penEntity = shadow[index/30]["pen"],
                            let modelEntity = penEntity as? ModelEntity {
                            if var material = (modelEntity.model?.materials.first as? PhysicallyBasedMaterial) {
                                let direction = normalize(middlePosition - indexPosition)
                                let penPosition = (thumbPosition + indexPosition) / 2
                                extendedPosition = penPosition + direction * 0.1
                                let inputValue = CGFloat(extendedPosition.y) - paperLevel
                                let normalizedProgress = normalizeToRange(value: inputValue, minValue: 0, maxValue: 0.05, minRange: 0, maxRange: 1)
                                setBaseColor(Material: &material, color: interpolatedColor(progress: normalizedProgress))
                                modelEntity.model?.materials = [material]
                            }
                        }
                    }
                }
            }
            
        }
        
        
        updateTLines()
        updateTmaterial()
        let angles = computeFingerAngles(handData:TCurrentData)
        for (key, angle) in angles {
            guard let entity = THandEntities[key] else { continue }

                let absAngle = abs(angle)
                let color = angleToRainbowColor(angle: absAngle)
                
                let material = SimpleMaterial(color: color, isMetallic: false)
                entity.model?.materials = [material]
            }
    }
    // 将角度映射到 0~1 之间
    func normalizeAngle(_ angle: Float) -> Float {
        return (min(angle, 180) - 90) / 90.0
    }

    // 角度 → 彩虹色 (Jet Colormap)
    func angleToRainbowColor(angle: Float) -> UIColor {
        let normAngle = normalizeAngle(angle)
        let hue = normAngle * 0.7
        return UIColor(hue: CGFloat(hue), saturation: 1.0, brightness: 1.0, alpha: 1.0)
    }

    
    // 计算两个向量的夹角（返回弧度）
    func calculateJointAngle(start: SIMD3<Float>, middle: SIMD3<Float>, end: SIMD3<Float>) -> Float {
        let v1 = normalize(start - middle)
        let v2 = normalize(end - middle)
        let dotProduct = dot(v1, v2)
        let radianAngle = acos(dotProduct)
            
        return radianAngle * (180 / .pi)
    }
    
    // 计算所有手指关节的角度
    func computeFingerAngles(handData: [String: CaliGestureModel.EntityPositionData]) -> [String: Float] {
        var angles: [String: Float] = [:]

        let jointPairs = [
            ("thumbKnuckle", "thumbIntermediateBase", "thumbIntermediateTip"),
            ("thumbIntermediateBase", "thumbIntermediateTip", "thumbTip"),
            
            ("indexFingerMetacarpal", "indexFingerKnuckle", "indexFingerIntermediateBase"),
            ("indexFingerKnuckle", "indexFingerIntermediateBase", "indexFingerIntermediateTip"),
            ("indexFingerIntermediateBase", "indexFingerIntermediateTip", "indexFingerTip"),
            
            ("middleFingerMetacarpal", "middleFingerKnuckle", "middleFingerIntermediateBase"),
            ("middleFingerKnuckle", "middleFingerIntermediateBase", "middleFingerIntermediateTip"),
            ("middleFingerIntermediateBase", "middleFingerIntermediateTip", "middleFingerTip"),
            
            ("ringFingerMetacarpal", "ringFingerKnuckle", "ringFingerIntermediateBase"),
            ("ringFingerKnuckle", "ringFingerIntermediateBase", "ringFingerIntermediateTip"),
            ("ringFingerIntermediateBase", "ringFingerIntermediateTip", "ringFingerTip"),
            
            ("littleFingerMetacarpal", "littleFingerKnuckle", "littleFingerIntermediateBase"),
            ("littleFingerKnuckle", "littleFingerIntermediateBase", "littleFingerIntermediateTip"),
            ("littleFingerIntermediateBase", "littleFingerIntermediateTip", "littleFingerTip"),
            
            ("indexFingerMetacarpal", "indexFingerKnuckle", "indexFingerIntermediateBase"),
           ("middleFingerMetacarpal", "middleFingerKnuckle", "middleFingerIntermediateBase"),
           ("ringFingerMetacarpal", "ringFingerKnuckle", "ringFingerIntermediateBase"),
           ("littleFingerMetacarpal", "littleFingerKnuckle", "littleFingerIntermediateBase"),
           ("wrist", "thumbKnuckle", "thumbIntermediateBase"),
            
            ("indexFingerMetacarpal", "wrist", "forearmArm")
        ]

        for (start, middle, end) in jointPairs {
            if let startPos = handData[start]?.position,
               let middlePos = handData[middle]?.position,
               let endPos = handData[end]?.position {
                let angle = calculateJointAngle(start: startPos, middle: middlePos, end: endPos)
                angles[middle] = angle
            }
        }

        return angles
    }
    func updateLines() {
            for (startKey, endKey) in connections {
                if let startEntity = handEntities[startKey],
                   let endEntity = handEntities[endKey],
                   let lineEntity = lineEntities["\(startKey)-\(endKey)"] {
                    
                    let startPosition = startEntity.position
                    let endPosition = endEntity.position
                    
                    let midPoint = (startPosition + endPosition) / 2
                    let distance = simd_distance(startPosition, endPosition)

                    let direction = normalize(endPosition - startPosition)
                    let rotation = simd_quatf(from: SIMD3<Float>(0, 1, 0), to: direction)
                    
                    lineEntity.position = midPoint
                    lineEntity.orientation = rotation
                    lineEntity.scale = SIMD3<Float>(1.0, distance*100, 1.0)

                }
            }
        }
        func updateTLines(){
            for (startKey, endKey) in connections {
                if let startEntity = THandEntities[startKey],
                   let endEntity = THandEntities[endKey],
                   let lineEntity = TlineEntities["\(startKey)-\(endKey)"] {
                    
                    let startPosition = startEntity.position
                    let endPosition = endEntity.position
                    
                    let midPoint = (startPosition + endPosition) / 2
                    let distance = simd_distance(startPosition, endPosition)

                    let direction = normalize(endPosition - startPosition)
                    let rotation = simd_quatf(from: SIMD3<Float>(0, 1, 0), to: direction)
                    
                    lineEntity.position = midPoint
                    lineEntity.orientation = rotation
                    lineEntity.scale = SIMD3<Float>(1.0, distance*100, 1.0)

                }
            }
        }

    func createColorTexture(color: UIColor) -> TextureResource? {
        let size = CGSize(width: 512, height: 512)
        UIGraphicsBeginImageContext(size)
        
        color.setFill()
        UIRectFill(CGRect(origin: .zero, size: size))
        
        let image = UIGraphicsGetImageFromCurrentImageContext()
        UIGraphicsEndImageContext()

        guard let uiImage = image else { return nil }
        
    
        guard let data = uiImage.pngData() else { return nil }
        let tempDirectory = FileManager.default.temporaryDirectory
        let fileURL = tempDirectory.appendingPathComponent("colorTexture.png")
        
        do {
            try data.write(to: fileURL)
            
          
            let texture = try? TextureResource.load(contentsOf: fileURL)
            return texture
        } catch {
            print("Failed to save image data: \(error)")
            return nil
        }
    }
    
    func setBaseColor(Material: inout PhysicallyBasedMaterial, color: UIColor) {
        if let greenTexture = createColorTexture(color: color) {
            let textureParameter = MaterialParameters.Texture(greenTexture)
            Material.baseColor = PhysicallyBasedMaterial.BaseColor(texture: textureParameter)
        }
    }
    

    
    
    func createSphereEntity() {
        var material = PhysicallyBasedMaterial()
        setBaseColor(Material: &material, color: .green)
        material.emissiveIntensity = 4.0
        material.emissiveColor = .init(color: .green)
        material.blending = .transparent(opacity: .init(floatLiteral: 0.01))
        teacherMaterials.append(material)
        for i in 1..<10 {
            var material = PhysicallyBasedMaterial()
            let opacity = Float(i) / 9.0
            setBaseColor(Material: &material, color: .green)
            material.emissiveIntensity = 4.0
            material.emissiveColor = .init(color: .green)
            material.blending = .transparent(opacity: .init(floatLiteral: opacity))
            teacherMaterials.append(material)
        }

        let penMesh = MeshResource.generateCylinder(height: 0.15, radius: 0.004)
        let coneMesh = MeshResource.generateCone(height: 0.02, radius: 0.01)
//        var fTPenMaterial = PhysicallyBasedMaterial()
//        setBaseColor(Material: &fTPenMaterial, color: .blue)
//        fTPenMaterial.blending = .transparent(opacity: .init(floatLiteral: 0.05))
//        fTPenMaterial.emissiveIntensity = 1.0
//        fTPenMaterial.emissiveColor = .init(color: .blue)
//        let fTPenEntity = ModelEntity(mesh: penMesh, materials: [fTPenMaterial])
//        var fmaterial = PhysicallyBasedMaterial()
//        setBaseColor(Material: &fmaterial, color: .green)
//        fmaterial.emissiveIntensity = 4.0
//        fmaterial.emissiveColor = .init(color: .green)
//        fmaterial.blending = .transparent(opacity: .init(floatLiteral: 0.05))
//        let fTArrowEntity = ModelEntity(mesh: coneMesh, materials: [fmaterial])
//        var fTEntitys: [String: ModelEntity] = [:]
//        fTEntitys["pen"] = fTPenEntity
//        fTEntitys["arrow"] = fTArrowEntity
//        shadow.append(fTEntitys)
        for i in 1..<6 {
            var TPenMaterial = PhysicallyBasedMaterial()
            let opacity = Float(6-i) / 6.0
            setBaseColor(Material: &TPenMaterial, color: .blue)
            TPenMaterial.blending = .transparent(opacity: .init(floatLiteral: opacity))
            TPenMaterial.emissiveIntensity = 1.0
            TPenMaterial.emissiveColor = .init(color: .blue)
            let TPenEntity = ModelEntity(mesh: penMesh, materials: [TPenMaterial])
            var material = PhysicallyBasedMaterial()
            setBaseColor(Material: &material, color: .green)
            material.emissiveIntensity = 1.0
            material.emissiveColor = .init(color: .green)
            material.blending = .transparent(opacity: .init(floatLiteral: opacity))
            let TArrowEntity = ModelEntity(mesh: coneMesh, materials: [material])
            var TEntitys: [String: ModelEntity] = [:]
            TEntitys["pen"] = TPenEntity
            TEntitys["arrow"] = TArrowEntity
            shadow.append(TEntitys)
        }
        let sphereMesh = MeshResource.generateSphere(radius: 0.004)
        var normalMaterial = SimpleMaterial(color: .yellow, isMetallic: true)
        var teacherMaterial = teacherMaterials[0]
        
        var penMaterial = PhysicallyBasedMaterial()
        setBaseColor(Material: &penMaterial, color: .blue)
        
        let arrowMaterial = SimpleMaterial(color: .yellow, isMetallic: true)
        let arrowEntity = ModelEntity(mesh: coneMesh, materials: [arrowMaterial])
        let TarrowMaterial = SimpleMaterial(color: .green, isMetallic: true)
        let TarrowEntity = ModelEntity(mesh: coneMesh, materials: [TarrowMaterial])
        let PenEntity = ModelEntity(mesh: penMesh, materials: [penMaterial])
        let TPenEntity = ModelEntity(mesh: penMesh, materials: [penMaterial])
        handEntities["arrow"] = arrowEntity
        handEntities["pen"] = PenEntity
        THandEntities["pen"] = TPenEntity
        THandEntities["arrow"] = TarrowEntity
        let rightHandJoints = [
            "thumbKnuckle", "thumbIntermediateBase", "thumbIntermediateTip", "thumbTip",
            "indexFingerMetacarpal", "indexFingerKnuckle", "indexFingerIntermediateBase", "indexFingerIntermediateTip", "indexFingerTip",
            "middleFingerMetacarpal", "middleFingerKnuckle", "middleFingerIntermediateBase", "middleFingerIntermediateTip", "middleFingerTip",
            "ringFingerMetacarpal", "ringFingerKnuckle", "ringFingerIntermediateBase", "ringFingerIntermediateTip", "ringFingerTip",
            "littleFingerMetacarpal", "littleFingerKnuckle", "littleFingerIntermediateBase", "littleFingerIntermediateTip", "littleFingerTip",
            "wrist","forearmArm"
        ]

        for joint in rightHandJoints {
            // 创建并存储手部关节的实体
            let entity = ModelEntity(mesh: sphereMesh, materials: [normalMaterial])
            handEntities[joint] = entity
            // 创建并存储教师手部关节的实体
            let teacherEntity = ModelEntity(mesh: sphereMesh, materials: [teacherMaterial])
            THandEntities[joint] = teacherEntity
            
            let lineMaterial = SimpleMaterial(color: .yellow, isMetallic: true)
            let TlineMaterial = SimpleMaterial(color: .green, isMetallic: true)
            for (startKey, endKey) in connections {
                if let startEntity = handEntities[startKey], let endEntity = handEntities[endKey] {
                    let startPosition = startEntity.position
                    let endPosition = endEntity.position

                    let midPoint = (startPosition + endPosition) / 2
                    let distance = simd_distance(startPosition, endPosition)

                    // 生成实心圆柱体（radius 控制粗细，height = distance）
                    let cylinderMesh = MeshResource.generateCylinder(height: 0.005, radius: 0.002)
                    let lineEntity = ModelEntity(mesh: cylinderMesh, materials: [lineMaterial])

                    // 计算旋转方向
                    let direction = normalize(endPosition - startPosition)
                    let rotation = simd_quatf(from: SIMD3<Float>(0, 1, 0), to: direction) // Cylinder 默认沿 Y 轴

                    lineEntity.position = midPoint
                    lineEntity.orientation = rotation

                    lineEntities["\(startKey)-\(endKey)"] = lineEntity
                    if(gestureModel.mode == .practice){
                        let lineEntity2 = ModelEntity(mesh: cylinderMesh, materials: [teacherMaterial])

                        // 计算旋转方向
                        let direction = normalize(endPosition - startPosition)
                        let rotation = simd_quatf(from: SIMD3<Float>(0, 1, 0), to: direction) // Cylinder 默认沿 Y 轴

                        lineEntity2.position = midPoint
                        lineEntity2.orientation = rotation

                        TlineEntities["\(startKey)-\(endKey)"] = lineEntity2
                    }
                }
            }
                    }
                }

    func fetchEntityData(from url: URL = URL(string: "http://10.16.63.206:9000")!, completion: @escaping (Data?, URLResponse?, Error?) -> Void) {
        
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        
        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error: \(error.localizedDescription)")
                completion(nil, nil, error)
                return
            }
            
            completion(data, response, nil)
        }.resume()
    }
}
