//
//  calitest_appApp.swift
//  calitest_app
//
//  Created by 陶文晖 on 2025/2/18.
//

import SwiftUI

@main
struct calitest_appApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
        .windowStyle(.volumetric)
        
        ImmersiveSpace(id: "writing") {
            ImmersiveView(gestureModel:
                HeartGestureModelContainer.heartGestureModel)
        }
        .immersionStyle(selection: .constant(.mixed), in: .mixed)
    }
}

@MainActor
enum HeartGestureModelContainer {
    static var heartGestureModel = CaliGestureModel()
}
