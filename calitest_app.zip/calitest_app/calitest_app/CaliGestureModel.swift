/*
See the LICENSE.txt file for this sample’s licensing information.

Abstract:
Hand tracking updates.
*/

import ARKit
import SwiftUI
import RealityKit
import RealityKitContent
import Foundation

/// A model that contains up-to-date hand coordinate information.
@MainActor
class CaliGestureModel: ObservableObject, @unchecked Sendable {
    let session = ARKitSession()
    var handTracking = HandTrackingProvider()
    @Published var recording: Bool = false
    @Published var changeWriting: Bool = false
    @Published var latestHandTracking: HandsUpdates = .init(left: nil, right: nil)
    @Published var mode: Mode = .practice 
    @Published var isImmersiveActive = false
    @Published var handTrackingData: [[String: EntityPositionData]] = []
    @Published var GestureIndex: Int = 0
    @Published var Xoffset: Double = 0
    @Published var Yoffset: Double = 0
    @Published var Zoffset: Double = 0
    var buffer: [[CGFloat]] = []
    var matchStartIndex = 0
    var rotated = false
    var pathData1: [[CGFloat]] = []
    var pathData2: [[CGFloat]] = []
    var pathData3: [[CGFloat]] = []

    let MAX_DIST_THRESHOLD = 0.2
    enum Mode {
            case practice
            case record
        }
    struct HandsUpdates {
        var left: HandAnchor?
        var right: HandAnchor?
    }
    
    @MainActor
    struct EntityPositionData: Codable {
        let position: SIMD3<Float>

        init(from entity: SIMD3<Float>) {
            self.position = entity
        }
        
    }
    func start() async {
        do {
            if HandTrackingProvider.isSupported {
                print("ARKitSession starting.")
                try await session.run([handTracking])
            }
        } catch {
            print("ARKitSession error:", error)
        }
    }
    // 旋转单个点的函数
    func rotatePoint(_ point: [CGFloat], around origin: [CGFloat], by angle: CGFloat) -> [CGFloat] {
        let dx = point[0] - origin[0]
        let dy = point[1] - origin[1]
        
        let rotatedX = origin[0] + cos(angle) * dx - sin(angle) * dy
        let rotatedY = origin[1] + sin(angle) * dx + cos(angle) * dy
        
        return [rotatedX, rotatedY]
    }
    
    func rotatePathToFitAngle(pathData1: [[CGFloat]], buffer: [[CGFloat]]) -> [[CGFloat]] {
        // 点数不够，直接返回原始
        if pathData1.count < 9 || buffer.count < 9 {
            return pathData1
        }

        // 原始方向
        let x1r = pathData1[1][0]
        let y1r = pathData1[1][1]
        let x2r = pathData1[7][0]
        let y2r = pathData1[7][1]
        let angleRef = atan2(y2r - y1r, x2r - x1r)

        // 当前方向
        let x1c = buffer[1][0]
        let y1c = buffer[1][1]
        let x2c = buffer[7][0]
        let y2c = buffer[7][1]
        let angleCur = atan2(y2c - y1c, x2c - x1c)

        let deltaAngle = angleCur - angleRef // 旋转角度

        // 以原始轨迹的起点为中心旋转整个 path_data_1
        let origin = [pathData1[0][0], pathData1[0][1]]
        let rotated = pathData1.map { point in
            return rotatePoint( [point[0], point[1]], around: origin, by: deltaAngle)
        }
        return rotated
    }
    
    // 获取方向的函数，计算从 p1 到 p2 的方向（角度，单位：弧度）
    func getDirection(p1: [CGFloat], p2: [CGFloat]) -> CGFloat {
        let dx = p2[0] - p1[0]
        let dy = p2[1] - p1[1]
        return atan2(dy, dx) // 返回弧度
    }

    // 对点进行扩展，返回相对于起始点的坐标、角度
    func enrich(points: [[CGFloat]]) -> [(CGFloat, CGFloat)] {
        // 如果点数小于 2，则返回空数组
        if points.count < 2 {
            return []
        }

        let x0 = points[0][0]
        let y0 = points[0][1]
        var enriched: [(CGFloat, CGFloat)] = []

        // 对于每一对连续的点，计算相对坐标和角度
        for i in 1..<points.count {
            let x = points[i][0]
            let y = points[i][1]
            let relX = x - x0
            let relY = y - y0
            let angle = getDirection(p1: points[i - 1], p2: points[i])
            enriched.append((relX, relY))
        }

        return enriched
    }
    
    
    
    
    func saveHandTrackingDataToFile(filename: String) {
        let encoder = JSONEncoder()
            do {
                // 编码数据并保存
                let data = try encoder.encode(handTrackingData)
                let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
                    .appendingPathComponent(filename)
                
                try data.write(to: fileURL)
                print("数据已保存：\(fileURL.path)")
            } catch {
                print("保存数据失败：\(error)")
            }
    }
    
    func loadHandTrackingDataFromFile(filename:String) -> [[String: EntityPositionData]]?  {
        let fileURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
            .appendingPathComponent(filename)
        
        do {
            let data = try Data(contentsOf: fileURL)
            
            // 解码数据
            let decoder = JSONDecoder()
            let loadedData = try decoder.decode([[String: EntityPositionData]].self, from: data)
            
            print("数据已加载")
            return loadedData
        } catch {
            print("加载数据失败：\(error)")
            return nil
        }
    }
    
    func publishHandTrackingUpdates() async {
        for await update in handTracking.anchorUpdates {
            switch update.event {
            case .updated:
                let anchor = update.anchor
                
                // Publish updates only if the hand and the relevant joints are tracked.
                guard anchor.isTracked else { continue }
                
                // Update left hand info.
                if anchor.chirality == .left {
                    latestHandTracking.left = anchor
                } else if anchor.chirality == .right { // Update right hand info.
                    latestHandTracking.right = anchor
                }
            default:
                break
            }
        }
    }
    
    func monitorSessionEvents() async {
        for await event in session.events {
            switch event {
            case .authorizationChanged(let type, let status):
                if type == .handTracking && status != .allowed {
                    // Stop the game, ask the user to grant hand tracking authorization again in Settings.
                }
            default:
                print("Session event \(event)")
            }
        }
    }

    /// Computes a transform representing the heart gesture performed by the user.
    ///
    /// - Returns:
    ///  * A right-handed transform for the heart gesture, where:
    ///     * The origin is in the center of the gesture
    ///     * The X axis is parallel to the vector from left thumb knuckle to right thumb knuckle
    ///     * The Y axis is parallel to the vector from right thumb tip to right index finger tip.
    ///  * `nil` if either of the hands isn't tracked or the user isn't performing a heart gesture
    ///  (the index fingers and thumbs of both hands need to touch).
    func computeTransformOfUserPerformedHeartGesture() -> [String: SIMD3<Float>]? {
        // Get the latest hand anchors, return false if either of them isn't tracked.
        guard let rightHandAnchor = latestHandTracking.right,
            rightHandAnchor.isTracked else {
            return nil
        }
        
        // Get all required joints and check if they are tracked.
        guard
            let rightHandThumbKnuckle = rightHandAnchor.handSkeleton?.joint(.thumbKnuckle),
               let rightHandThumbTip = rightHandAnchor.handSkeleton?.joint(.thumbTip),
            let rightHandThumbIntermediateBase = rightHandAnchor.handSkeleton?.joint(.thumbIntermediateBase),
            let rightHandThumbIntermediateTip = rightHandAnchor.handSkeleton?.joint(.thumbIntermediateTip),
               
               let rightHandIndexFingerMetacarpal = rightHandAnchor.handSkeleton?.joint(.indexFingerMetacarpal),
               let rightHandIndexFingerKnuckle = rightHandAnchor.handSkeleton?.joint(.indexFingerKnuckle),
                let rightHandIndexFingerIntermediateBase = rightHandAnchor.handSkeleton?.joint(.indexFingerIntermediateBase),
                let rightHandIndexFingerIntermediateTip = rightHandAnchor.handSkeleton?.joint(.indexFingerIntermediateTip),
               let rightHandIndexFingerTip = rightHandAnchor.handSkeleton?.joint(.indexFingerTip),
               
               let rightHandMiddleFingerMetacarpal = rightHandAnchor.handSkeleton?.joint(.middleFingerMetacarpal),
               let rightHandMiddleFingerKnuckle = rightHandAnchor.handSkeleton?.joint(.middleFingerKnuckle),
                let rightHandMiddleFingerIntermediateBase = rightHandAnchor.handSkeleton?.joint(.middleFingerIntermediateBase),
                let rightHandMiddleFingerIntermediateTip = rightHandAnchor.handSkeleton?.joint(.middleFingerIntermediateTip),
               let rightHandMiddleFingerTip = rightHandAnchor.handSkeleton?.joint(.middleFingerTip),
               
               let rightHandRingFingerMetacarpal = rightHandAnchor.handSkeleton?.joint(.ringFingerMetacarpal),
               let rightHandRingFingerKnuckle = rightHandAnchor.handSkeleton?.joint(.ringFingerKnuckle),
                let rightHandRingFingerIntermediateBase = rightHandAnchor.handSkeleton?.joint(.ringFingerIntermediateBase),
                let rightHandRingFingerIntermediateTip = rightHandAnchor.handSkeleton?.joint(.ringFingerIntermediateTip),
               let rightHandRingFingerTip = rightHandAnchor.handSkeleton?.joint(.ringFingerTip),
               
               let rightHandLittleFingerMetacarpal = rightHandAnchor.handSkeleton?.joint(.littleFingerMetacarpal),
               let rightHandLittleFingerKnuckle = rightHandAnchor.handSkeleton?.joint(.littleFingerKnuckle),
                let rightHandLittleFingerIntermediateBase = rightHandAnchor.handSkeleton?.joint(.littleFingerIntermediateBase),
                let rightHandLittleFingerIntermediateTip = rightHandAnchor.handSkeleton?.joint(.littleFingerIntermediateTip),
               let rightHandLittleFingerTip = rightHandAnchor.handSkeleton?.joint(.littleFingerTip),
               
               let rightHandWrist = rightHandAnchor.handSkeleton?.joint(.wrist),

               (rightHandThumbKnuckle.isTracked && rightHandThumbTip.isTracked &&
                rightHandThumbIntermediateBase.isTracked && rightHandThumbIntermediateTip.isTracked) &&
               (rightHandIndexFingerMetacarpal.isTracked && rightHandIndexFingerKnuckle.isTracked &&
                rightHandIndexFingerIntermediateBase.isTracked && rightHandIndexFingerTip.isTracked && rightHandIndexFingerIntermediateTip.isTracked)&&(
               rightHandMiddleFingerMetacarpal.isTracked && rightHandMiddleFingerKnuckle.isTracked &&
               rightHandMiddleFingerIntermediateBase.isTracked && rightHandMiddleFingerTip.isTracked && rightHandMiddleFingerIntermediateTip.isTracked) && (
               rightHandRingFingerMetacarpal.isTracked && rightHandRingFingerKnuckle.isTracked &&
               rightHandRingFingerIntermediateBase.isTracked && rightHandRingFingerTip.isTracked && rightHandRingFingerIntermediateTip.isTracked) && (
               rightHandLittleFingerMetacarpal.isTracked && rightHandLittleFingerKnuckle.isTracked &&
               rightHandLittleFingerIntermediateBase.isTracked && rightHandLittleFingerTip.isTracked && rightHandLittleFingerIntermediateTip.isTracked) &&
               rightHandWrist.isTracked
        else {
            return nil
        }
        
        let rightHandJoints: [HandSkeleton.JointName] = [
            .thumbKnuckle, .thumbIntermediateBase, .thumbIntermediateTip, .thumbTip,
            .indexFingerMetacarpal, .indexFingerKnuckle, .indexFingerIntermediateBase, .indexFingerIntermediateTip, .indexFingerTip,
            .middleFingerMetacarpal, .middleFingerKnuckle, .middleFingerIntermediateBase, .middleFingerIntermediateTip, .middleFingerTip,
            .ringFingerMetacarpal, .ringFingerKnuckle, .ringFingerIntermediateBase, .ringFingerIntermediateTip, .ringFingerTip,
            .littleFingerMetacarpal, .littleFingerKnuckle, .littleFingerIntermediateBase, .littleFingerIntermediateTip, .littleFingerTip,
            .wrist, .forearmArm
        ]

        var jointPositions: [HandSkeleton.JointName: SIMD3<Float>] = [:]

        for jointName in rightHandJoints {
            if let joint = rightHandAnchor.handSkeleton?.joint(jointName) {
                jointPositions[jointName] = matrix_multiply(
                    rightHandAnchor.originFromAnchorTransform,
                    joint.anchorFromJointTransform
                ).columns.3.xyz
            }
        }
        
        let jointPositionsAsString: [String: SIMD3<Float>] = Dictionary(
            uniqueKeysWithValues: jointPositions.map { (key, value) in
                (String(describing: key), value)
            }
        )
        return jointPositionsAsString
    }

    func difference(_ a: (CGFloat, CGFloat), _ b: (CGFloat, CGFloat)) -> CGFloat {
        let dx = a.0 - b.0
        let dy = a.1 - b.1
        return sqrt(dx * dx + dy * dy)
    }

    // Function to calculate norm distance (L2 norm)
    func norm(p: Int) -> (CGFloat, CGFloat) -> CGFloat {
        return { a, b in
            return sqrt(pow(a - b, CGFloat(p)))
        }
    }

    // FastDTW function
    func fastDTW(x: [(CGFloat,CGFloat)], y: [(CGFloat,CGFloat)], radius: Int = 1, dist: (((CGFloat, CGFloat),(CGFloat, CGFloat)) -> CGFloat)? = nil) -> (CGFloat, [(Int, Int)]) {
        let (x, y, dist) = prepInputs(x: x, y: y, dist: dist)
        return fastDTWRecursive(x: x, y: y, radius: radius, dist: dist)
    }

    // Preparation of inputs (handles default distance and validation)
    func prepInputs(x: [(CGFloat,CGFloat)], y: [(CGFloat,CGFloat)], dist: (((CGFloat, CGFloat),(CGFloat, CGFloat)) -> CGFloat)?) -> ([(CGFloat,CGFloat)], [(CGFloat,CGFloat)], ((CGFloat, CGFloat),(CGFloat, CGFloat)) -> CGFloat) {
        // 如果 dist 为空则使用 default difference 函数
        let dist: ((CGFloat, CGFloat), (CGFloat, CGFloat)) -> CGFloat = dist ?? difference

        if x.count != y.count {
            print(x)
            print(y)
            fatalError("x and y must have the same length")
        }

        return (x, y, dist)
    }

    // FastDTW recursive function with approximation
    func fastDTWRecursive(x: [(CGFloat,CGFloat)], y: [(CGFloat,CGFloat)], radius: Int, dist: @escaping ((CGFloat, CGFloat),(CGFloat, CGFloat)) -> CGFloat) -> (CGFloat, [(Int, Int)]) {
        let minTimeSize = radius + 2

        if x.count < minTimeSize || y.count < minTimeSize {
            return dtw(x: x, y: y, dist: dist)
        }

        let xShrinked = reduceByHalf(x: x)
        let yShrinked = reduceByHalf(x: y)

        let (distance, path) = fastDTWRecursive(x: xShrinked, y: yShrinked, radius: radius, dist: dist)
        let window = expandWindow(path: path, lenX: x.count, lenY: y.count, radius: radius)
        
        return dtw(x: x, y: y, dist: dist)
    }

    typealias DTWEntry = (cost: CGFloat, i: Int, j: Int)

    func dtw<T>(x: [(T,T)], y: [(T,T)], dist: @escaping ((T, T), (T, T)) -> CGFloat) -> (CGFloat, [(Int, Int)]){
        let lenX = x.count
        let lenY = y.count

        // 使用 [String: DTWEntry] 做一个类 default dict 的效果
        var D: [String: DTWEntry] = [:]
        func key(_ i: Int, _ j: Int) -> String {
            return "\(i)-\(j)"
        }
        D[key(0, 0)] = (0.0, 0, 0)

        for i in 1...lenX {
            for j in 1...lenY {
                let cost = dist(x[i - 1], y[j - 1])

                let d1 = D[key(i - 1, j)]?.cost ?? CGFloat.infinity
                let d2 = D[key(i, j - 1)]?.cost ?? CGFloat.infinity
                let d3 = D[key(i - 1, j - 1)]?.cost ?? CGFloat.infinity

                let (minCost, prevI, prevJ): DTWEntry
                if d1 <= d2 && d1 <= d3 {
                    minCost = d1 + cost
                    prevI = i - 1
                    prevJ = j
                } else if d2 <= d3 {
                    minCost = d2 + cost
                    prevI = i
                    prevJ = j - 1
                } else {
                    minCost = d3 + cost
                    prevI = i - 1
                    prevJ = j - 1
                }

                D[key(i, j)] = (minCost, prevI, prevJ)
            }
        }

        // 回溯路径
        var path: [(Int, Int)] = []
        var i = lenX
        var j = lenY
        while i != 0 || j != 0 {
            path.append((i - 1, j - 1))
            let entry = D[key(i, j)]!
            i = entry.i
            j = entry.j
        }

        path.reverse()
        let finalCost = D[key(lenX, lenY)]!.cost
        return (finalCost, path)
    }

    func reduceByHalf(x: [(CGFloat, CGFloat)]) -> [(CGFloat, CGFloat)] {
        let halfCount = x.count / 2
        var result = [(CGFloat, CGFloat)]()
        result.reserveCapacity(halfCount)
        
        for i in 0..<halfCount {
            let first = x[2 * i]
            let second = x[2 * i + 1]
            let avgX = (first.0 + second.0) / 2
            let avgY = (first.1 + second.1) / 2
            result.append((avgX, avgY))
        }
        
        return result
    }

    // Expand window for warping path
    func expandWindow(path: [(Int, Int)], lenX: Int, lenY: Int, radius: Int) -> [(Int, Int)] {
        var pathSet = Set<CGPoint>(path.map { CGPoint(x: $0.0, y: $0.1) }) // 转为CGPoint类型

        for (i, j) in path {
            for a in -radius...radius {
                for b in -radius...radius {
                    pathSet.insert(CGPoint(x: i + a, y: j + b)) // 插入新的偏移点，自动去重
                }
            }
        }

        var window: [(Int, Int)] = []
        var startJ = 0
        for i in 0..<lenX {
            var newStartJ: Int? = nil
            for j in startJ..<lenY {
                if pathSet.contains(CGPoint(x: CGFloat(i), y: CGFloat(j))) {
                    window.append((i, j))
                    if newStartJ == nil {
                        newStartJ = j
                    }
                } else if newStartJ != nil {
                    break
                }
            }
            startJ = newStartJ ?? startJ
        }

        return window
    }

    func recordPoint(x: CGFloat, y:CGFloat) {
        buffer.append([x, y])
        // drawPoint(x, y, color: .red)

        if !rotated && buffer.count >= 10 {
            pathData3 = rotatePathToFitAngle(pathData1: pathData1, buffer: buffer)
            if pathData1.count >= 8 && buffer.count >= 8 {
                let originalAngle = getDirection(p1: pathData1[1], p2: pathData1[7])
                let actualAngle = getDirection(p1: buffer[1], p2: buffer[7])
                let angleOffset = actualAngle - originalAngle
                let origin = pathData1[0]
                pathData3 = pathData1.map { rotatePoint($0, around: origin, by: angleOffset) }
                rotated = true
                print("轨迹已旋转一次用于匹配")
            } else {
                pathData3 = pathData1
            }
        }

        if buffer.count >= 11 && matchStartIndex < pathData1.count - 10 {
            let enrichedBuffer = enrich(points: buffer)
            var bestDist = CGFloat.infinity
            var bestEndIndex = matchStartIndex + 10
            var bestSegment: [[CGFloat]] = []

            let windowSize = 11
            if matchStartIndex + windowSize <= pathData3.count {
                let segment = Array(pathData3[matchStartIndex..<matchStartIndex + windowSize])
                let enrichedSegment = enrich(points: segment)
                let (dist, _) = fastDTW(x: enrichedBuffer, y: enrichedSegment, dist: difference)
                if dist < bestDist {
                    bestDist = dist
                    bestEndIndex = matchStartIndex + windowSize
                    bestSegment = segment
                }
            }
            
            if bestDist < MAX_DIST_THRESHOLD {
                let originalSegment = Array(pathData1[matchStartIndex..<bestEndIndex])
                let xs = originalSegment.map { $0[0] }
                let ys = originalSegment.map { $0[1] }
                // drawLine(xs: xs, ys: ys)

                pathData2.append(contentsOf: buffer)
                matchStartIndex = bestEndIndex
//                print("匹配成功！DTW距离: \(bestDist)，起点更新为 \(matchStartIndex)")
            } else {
//                print("匹配失败，距离太远：\(bestDist)")
            }

            buffer = []
        }
        else if matchStartIndex >= pathData1.count - 10{
            matchStartIndex = 0
            print(matchStartIndex)
        }
        
    }

    
}
