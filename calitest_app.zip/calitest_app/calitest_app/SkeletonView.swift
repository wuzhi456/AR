import SwiftUI
import RealityKit
import RealityKitContent

struct SkeletonView: View {
    var body: some View {
        RealityView { content in
            setupHandTracking(in: content)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }

    func setupHandTracking(in content: RealityViewContent) {
        // 创建一个 InputEntity 来检测手部数据
        let handTrackingEntity = InputEntity()
        content.add(handTrackingEntity)

        // 颜色映射不同手指的关节
        let jointColors: [HandJointName: UIColor] = [
            .thumbTip: .red, .thumbIP: .red, .thumbMP: .red, .thumbCMC: .red,
            .indexTip: .green, .indexDIP: .green, .indexPIP: .green, .indexMCP: .green,
            .middleTip: .blue, .middleDIP: .blue, .middlePIP: .blue, .middleMCP: .blue,
            .ringTip: .yellow, .ringDIP: .yellow, .ringPIP: .yellow, .ringMCP: .yellow,
            .littleTip: .purple, .littleDIP: .purple, .littlePIP: .purple, .littleMCP: .purple
        ]

        // 创建一个存储手指关节球体的字典
        var jointEntities: [HandJointName: ModelEntity] = [:]

        for joint in HandJointName.allCases {
            let color = jointColors[joint] ?? .white  // 如果找不到颜色，默认白色
            let sphere = createSphereEntity(color: color)
            jointEntities[joint] = sphere
            content.add(sphere)
        }

        // 监听手势数据更新
        handTrackingEntity.input.onHandTrackingUpdated = { input, hand in
            for joint in HandJointName.allCases {
                if let transform = hand.jointTransform(joint), let entity = jointEntities[joint] {
                    entity.position = transform.position  // 更新关节位置
                }
            }
        }
    }

    // 创建小球实体（用于表示关节）
    func createSphereEntity(color: UIColor) -> ModelEntity {
        let sphereMesh = MeshResource.generateSphere(radius: 0.005) // 5mm 球
        let material = SimpleMaterial(color: color, isMetallic: false)
        let sphereEntity = ModelEntity(mesh: sphereMesh, materials: [material])
        return sphereEntity
    }
}

// Vision Pro 预览
#Preview(windowStyle: .volumetric) {
    SkeletonView()
}
