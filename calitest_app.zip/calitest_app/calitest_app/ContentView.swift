import SwiftUI
import RealityKit
import RealityKitContent



struct ContentView: View {
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @ObservedObject var gestureModel = HeartGestureModelContainer.heartGestureModel

    
    @State private var exerciseItems: [ExerciseItem] = []
    @State private var countdown: Int = 3
    @State private var isCountingDown: Bool = false
    @State private var countdownTimer: Timer?
    @State private var showAlert = false
    @State private var fileName: String = ""
    @State private var selectedItem: UUID?
    struct ExerciseItem: Identifiable {
            let id = UUID()
            let name: String
            let image: String
        }


    var body: some View {
        ZStack {
                VStack(spacing: 20) {
                    Text("mode: \(gestureModel.mode == .practice ? "practice" : "record")")
                        .font(.title)
                        .padding()

                    HStack {
                        Button("switch to practice") {
                            gestureModel.mode = .practice
                            loadSavedFiles()
                        }
                        .padding()
                        .background(gestureModel.mode == .practice ? Color.green : Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .disabled(isCountingDown)
                        .disabled(gestureModel.isImmersiveActive)

                        Button("switch to record") {
                            gestureModel.mode = .record
                            gestureModel.handTrackingData = []
                        }
                        .padding()
                        .background(gestureModel.mode == .record ? Color.red : Color.gray)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .disabled(isCountingDown)
                        .disabled(gestureModel.isImmersiveActive)
                        
                        VStack(spacing: 20) {
                            Text("Xoffset: \(gestureModel.Xoffset, specifier: "%.2f")")
                                        .font(.title)
                                    
                            Slider(value: $gestureModel.Xoffset, in: -2...2, step: 0.01)
                                        .padding()
                                    
                            Text("Yoffset: \(gestureModel.Yoffset, specifier: "%.2f")")
                                        .font(.title)
                                    
                            Slider(value: $gestureModel.Yoffset, in: -2...2, step: 0.01)
                                        .padding()
                                    
                            Text("Zoffset: \(gestureModel.Zoffset, specifier: "%.2f")")
                                        .font(.title)
                                    
                            Slider(value: $gestureModel.Zoffset, in: -2...2, step: 0.01)
                                        .padding()
                                }
                                .padding()
                    }

                    if gestureModel.mode == .practice {
//                        Button(gestureModel.changeWriting ? "stop changeWriting" : "changeWriting") {
//                            gestureModel.changeWriting = !gestureModel.changeWriting
//                        }
//                        .padding()
//                        .background(Color.blue)
//                        .foregroundColor(.white)
//                        .cornerRadius(10)
                        
                        List(selection: $selectedItem) {
                                ForEach(exerciseItems) { item in
                                    HStack {
                                        Image(systemName: item.image)
                                            .resizable()
                                            .frame(width: 40, height: 40)
                                            .padding()
                                        Text(item.name)
                                            .font(.headline)
                                        Spacer()
                                        if selectedItem == item.id {
                                            Image(systemName: "checkmark.circle.fill")
                                                .foregroundColor(.green) // 选中后显示勾选
                                        }
                                    }
                                    .contentShape(Rectangle()) // 让整个 HStack 可点击
                                    .onTapGesture {
                                        selectedItem = item.id // 记录选中项
                                    }
                                    .background(selectedItem == item.id ? Color.blue.opacity(0.3) : Color.clear) // 选中时高亮
                                }
                            }
                            .frame(height: 400)
                    }
                    HStack {
                        Button(gestureModel.isImmersiveActive ? "exit" : "start") {
                            gestureModel.GestureIndex = 0
                            toggleImmersiveSpace()
                        }
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(10)
                        .disabled(isCountingDown)
                        
                        if gestureModel.mode == .record && !showAlert {
                            Button("save") {
                                showAlert = true
                            }
                            .padding()
                            .background(Color.blue)
                            .foregroundColor(.white)
                            .cornerRadius(10)
                            .disabled(isCountingDown)
                        }
                    }
                }

                // 倒计时文本层级最高，覆盖所有 UI 元素
                if isCountingDown {
                    Text("\(countdown)")
                        .font(.system(size: 100, weight: .bold))
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.black.opacity(0.7)) // 半透明黑色背景，增强可视性
                        .cornerRadius(20)
                        .shadow(radius: 10)
                        .transition(.scale)
                        .animation(.easeInOut, value: countdown)
                }
            if showAlert {
                SaveFileView(fileName: $fileName, onSave: {
                    gestureModel.saveHandTrackingDataToFile(filename: fileName + ".json")
                    showAlert = false
                }, onCancel: { showAlert = false })
            }
            }
        .onAppear {
            loadSavedFiles()
            countdownTimer?.invalidate() }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        
        
    }
    func loadSavedFiles() {
            let fileManager = FileManager.default
            let documentsURL = fileManager.urls(for: .documentDirectory, in: .userDomainMask).first!

            do {
                let files = try fileManager.contentsOfDirectory(at: documentsURL, includingPropertiesForKeys: nil)

                let jsonFiles = files.filter { $0.pathExtension == "json" }  // 仅获取 .json 文件

                exerciseItems = jsonFiles.map { fileURL in
                    ExerciseItem(name: fileURL.lastPathComponent, image: "doc.text")
                }
            } catch {
                print("无法获取文件列表: \(error)")
            }
        }
    private func toggleImmersiveSpace() {
        if gestureModel.mode == .record && !gestureModel.isImmersiveActive {
            isCountingDown = true
            countdown = 3
            countdownTimer?.invalidate()
            countdownTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true)
            { timer in if self.countdown > 1 { self.countdown -= 1 }
                else {
                    timer.invalidate()
                    Task { @MainActor in
                        gestureModel.GestureIndex = 0
                        self.isCountingDown = false
                        self.countdown = 0
                        gestureModel.isImmersiveActive = true
                        await openImmersiveSpace(id: "writing")
                    }
                }
            }
        }
        else {
            Task { if gestureModel.isImmersiveActive {
                await dismissImmersiveSpace()
            }
                else {
                    if (gestureModel.mode == .practice){
                        if let selectedName = exerciseItems.first(where: { $0.id == selectedItem })?.name {
                            if let loadedData = gestureModel.loadHandTrackingDataFromFile(filename: selectedName) {
                                gestureModel.handTrackingData = loadedData
                            } else {
                                gestureModel.handTrackingData = [] // 如果加载失败，设置为空数组
                            }
                        }
                    }
                    await openImmersiveSpace(id: "writing")
                }
                gestureModel.isImmersiveActive.toggle()
            }
        }
    }
}

struct SaveFileView: View {
    @Binding var fileName: String
    var onSave: () -> Void
    var onCancel: () -> Void
    var body: some View {
        VStack(spacing: 20) {
            Text("Type in file name")
                .font(.title)

            TextField("fileName", text: $fileName)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()

            HStack {
                Button("Cancel") {
                    fileName = ""
                    onCancel()
                }
                .padding()
                .background(Color.gray)
                .foregroundColor(.white)
                .cornerRadius(10)

                Button("Save") {
                    onSave()
                }
                .padding()
                .background(Color.blue)
                .foregroundColor(.white)
                .cornerRadius(10)
            }
        }
        .padding()
        .background(Color.black.opacity(0.7))
    }
}

#Preview(windowStyle: .volumetric) {
    ContentView()
}
