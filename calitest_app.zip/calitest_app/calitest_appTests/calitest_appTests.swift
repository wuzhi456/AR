//
//  calitest_appTests.swift
//  calitest_appTests
//
//  Created by 陶文晖 on 2025/2/18.
//

import Testing
@testable import calitest_app

struct calitest_appTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
